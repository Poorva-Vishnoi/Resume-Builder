import "./App.css";
import Form from "./components/Form";

function App() {
  return (
    <div className="App">
      <h1 className="text-center">Let's generate your Resume!</h1>
      <Form />
    </div>
  );
}

export default App;
